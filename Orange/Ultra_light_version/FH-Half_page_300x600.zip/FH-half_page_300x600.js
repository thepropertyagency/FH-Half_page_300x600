(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.IMG01jpgcopy = function() {
	this.initialize(img.IMG01jpgcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,556);


(lib.IMG02jpgcopy = function() {
	this.initialize(img.IMG02jpgcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,556);


(lib.IMG03 = function() {
	this.initialize(img.IMG03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,480,300);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG03();
	this.instance.parent = this;
	this.instance.setTransform(-179,-111.85,0.7458,0.7458);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179,-111.8,358,223.7);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG03();
	this.instance.parent = this;
	this.instance.setTransform(-179,-111.85,0.7458,0.7458);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179,-111.8,358,223.7);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG02jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG02jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG01jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG01jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgbA0IAAhnIAOAAIAABZIApAAIAAAOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(-2.8,-5.1,5.6,10.3), null);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgbA0IAAhnIAOAAIAABZIApAAIAAAOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(-2.8,-5.1,5.6,10.3), null);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgGA0IAAhnIANAAIAABng");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(-0.7,-5.1,1.4,10.3), null);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AAZA0IAAgtIgxAAIAAAtIgOAAIAAhnIAOAAIAAAuIAxAAIAAguIAOAAIAABng");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(-3.9,-5.1,7.8,10.3), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgdA0IAAhnIA7AAIAAAOIgtAAIAAAgIAkAAIAAANIgkAAIAAAsg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(-3,-5.1,6,10.3), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgGA0IAAhnIANAAIAABng");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-0.7,-5.1,1.4,10.3), null);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgfA0IAAhnIA9AAIAAAOIguAAIAAAgIAoAAIAAANIgoAAIAAAeIAvAAIAAAOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(-3.1,-5.1,6.300000000000001,10.3), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgeA0IAAhnIA8AAIAAAOIguAAIAAAgIAoAAIAAANIgoAAIAAAeIAvAAIAAAOg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-3.1,-5.1,6.300000000000001,10.3), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgGA0IAAhZIgfAAIAAgOIBLAAIAAAOIgfAAIAABZg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-3.8,-5.1,7.699999999999999,10.3), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgPBMIAAiXIAfAAIAACXg");
	this.shape.setTransform(62.7,5.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2E2E2E").s().p("AgPBMIAAiXIAfAAIAACXg");
	this.shape_1.setTransform(56.7,5.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2E2E2E").s().p("AgPBOIAAhoIAfAAIAABogAgMgtQgGgFAAgIQAAgIAGgFQAFgGAHABQAHgBAGAGQAGAFgBAIQABAIgGAFQgGAGgHAAQgHAAgFgGg");
	this.shape_2.setTransform(50.75,5.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2E2E2E").s().p("AAeBLIAAg8Ig7AAIAAA8IghAAIAAiVIAhAAIAAA7IA7AAIAAg7IAhAAIAACVg");
	this.shape_3.setTransform(39.85,6.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2E2E2E").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_4.setTransform(20.975,8.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2E2E2E").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_5.setTransform(9.275,8.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2E2E2E").s().p("AggA1IAAhoIAfAAIAAAOQAGgPAUAAIAIABIAAAgIgKgBQgKAAgHAGQgGAIAAANIAAAug");
	this.shape_6.setTransform(-0.325,8.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2E2E2E").s().p("AgHA7QgIgIgBgQIAAgsIgSAAIAAgcIAFAAQAQAAAAgRIAAgOIAcAAIAAAfIAUAAIAAAcIgUAAIAAAmQAAALALAAIAJgBIAAAbQgGACgLAAQgQABgJgKg");
	this.shape_7.setTransform(-9.3,6.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2E2E2E").s().p("AglA/QgOgLgCgOIAcgIQACAHAGAFQAGAFAJAAQAYAAAAgbIAAgFQgHAMgTAAQgVAAgOgOQgOgOAAgWQAAgVAOgOQANgPAWgBQAUABAHANIAAgMIAfAAIAABbQAAAYgNAPQgPARgbAAQgVAAgPgMgAgOgoQgHAHAAAKQAAALAGAGQAHAGAIAAQAKAAAGgGQAHgGAAgLQAAgKgHgHQgGgGgKAAQgIAAgGAGg");
	this.shape_8.setTransform(-19.675,10.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2E2E2E").s().p("AgPBOIAAhoIAfAAIAABogAgMgtQgGgFABgIQgBgIAGgFQAGgGAGABQAIgBAFAGQAGAFAAAIQAAAIgGAFQgFAGgIAAQgGAAgGgGg");
	this.shape_9.setTransform(-28.7,5.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2E2E2E").s().p("AgvBLIAAiVIBfAAIAAAgIg9AAIAAAfIA2AAIAAAeIg2AAIAAA4g");
	this.shape_10.setTransform(-37.2,6.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2E2E2E").s().p("AgGA7QgKgIABgQIAAgsIgTAAIAAgcIAFAAQAQAAAAgRIAAgOIAcAAIAAAfIAUAAIAAAcIgUAAIAAAmQAAALAMAAIAIgBIAAAbQgGACgLAAQgQABgIgKg");
	this.shape_11.setTransform(-53,6.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2E2E2E").s().p("AgmAuQgJgJAAgOQAAgNAJgIQAIgHAOgCIAXgEQAJgBgBgGQAAgFgDgDQgFgDgHAAQgHAAgFAEQgEAFgBAGIgcgGQABgNALgKQANgLAUAAQAYAAAMAMQALAKAAASIAAAyIABAQIgdAAIgBgMQgJAPgUAAQgQAAgLgJgAgDAKQgMACAAAJQAAALAMAAQATAAgBgVIAAgEg");
	this.shape_12.setTransform(-62.65,8.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_13.setTransform(79.425,-16.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgNA0IgrhnIAiAAIAXBAIAXhAIAiAAIgpBng");
	this.shape_14.setTransform(67.65,-16.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgPBOIAAhoIAfAAIAABogAgMgtQgFgFgBgIQABgIAFgFQAGgGAGAAQAHAAAGAGQAGAFgBAIQABAIgGAFQgGAGgHAAQgGAAgGgGg");
	this.shape_15.setTransform(58.75,-18.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgPBMIAAiXIAfAAIAACXg");
	this.shape_16.setTransform(52.75,-18.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgnAoQgPgQAAgYQAAgXAPgQQARgPAWAAQAYAAAPAPQAQAQABAXQgBAYgQAQQgPAPgYAAQgWAAgRgPgAgPgTQgIAHAAAMQAAAMAIAIQAHAGAIAAQAKAAAGgGQAIgIgBgMQABgMgIgHQgGgGgKAAQgJAAgGAGg");
	this.shape_17.setTransform(38.45,-16.325);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgGA8QgKgKABgPIAAgsIgTAAIAAgcIAFAAQAQAAAAgRIAAgNIAcAAIAAAeIAUAAIAAAcIgUAAIAAAmQAAALAMAAIAIgBIAAAbQgGADgLAAQgQAAgIgJg");
	this.shape_18.setTransform(28,-17.75);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgGA8QgJgKAAgPIAAgsIgTAAIAAgcIAFAAQAQAAAAgRIAAgNIAcAAIAAAeIAUAAIAAAcIgUAAIAAAmQAAALALAAIAJgBIAAAbQgGADgLAAQgQAAgIgJg");
	this.shape_19.setTransform(14.85,-17.75);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AggArQgJgJgBgLIAbgFQABAGAEAEQAEAEAHAAQAMAAAAgJQAAgHgKgCIgLgCQgfgHAAgZQAAgOALgKQALgKARAAQAUAAALALQAJAIABAMIgaAFQgCgNgNAAQgEAAgDACQgDADAAAEQAAAGAIACIANACQAQAEAIAIQAIAIAAAMQAAAPgKAJQgMALgUAAQgVAAgMgMg");
	this.shape_20.setTransform(6.175,-16.325);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AggA1IAAhoIAfAAIAAAOQAGgPAUAAIAIABIAAAgIgKgBQgKAAgHAGQgGAIAAANIAAAug");
	this.shape_21.setTransform(-2.375,-16.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgPBOIAAhoIAfAAIAABogAgMgtQgGgFABgIQgBgIAGgFQAFgGAHAAQAHAAAGAGQAFAFABAIQgBAIgFAFQgGAGgHAAQgHAAgFgGg");
	this.shape_22.setTransform(-10.05,-18.85);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgSBNIAAhNIgRAAIAAgbIARAAIAAgJQAAgSAKgLQAKgLATAAQAKAAAFACIAAAaIgKgBQgNAAAAAOIAAAIIAWAAIAAAbIgWAAIAABNg");
	this.shape_23.setTransform(-16.825,-18.775);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_24.setTransform(-31.625,-16.325);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AARBMIAAg8QAAgRgRAAQgGAAgFADQgFAFAAAHIAAA+IggAAIAAiXIAgAAIAAA2QAJgJARAAQATAAALAMQAJALAAASIAABBg");
	this.shape_25.setTransform(-43.65,-18.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgHA8QgIgKgBgPIAAgsIgSAAIAAgcIAFAAQAQAAAAgRIAAgNIAcAAIAAAeIAUAAIAAAcIgUAAIAAAmQAAALALAAIAJgBIAAAbQgGADgLAAQgQAAgJgJg");
	this.shape_26.setTransform(-54.2,-17.75);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_27.setTransform(-68.925,-16.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Ag0BLIAAiVIA2AAQAWAAANAMQAMALgBASQABALgHAJQgGAIgJADQALACAHAJQAJAKAAANQAAASgOAMQgNANgVAAgAgUAwIAUAAQAJgBAGgFQAFgEAAgIQAAgIgFgFQgGgEgJAAIgUAAgAgUgNIASAAQAIgBAFgEQAFgFAAgHQAAgQgTAAIgRAAg");
	this.shape_28.setTransform(-80.8,-18.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-91.3,-34,180.2,55.2), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgfAyIAAhiIAeAAIAAANQAGgOASAAIAIABIAAAeIgJgBQgKAAgGAGQgGAHAAANIAAArg");
	this.shape.setTransform(63.75,27.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgkAnQgKgKAAgRIAAg+IAeAAIAAA4QAAAHAEAFQAEAFAIAAQAHAAAEgFQAFgFAAgHIAAg4IAeAAIAABRIABASIgdAAIgBgKQgHAMgTAAQgRAAgKgMg");
	this.shape_1.setTransform(53.325,27.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAQBIIAAg4QAAgRgQAAQgGAAgFADQgEAFAAAHIAAA6IgfAAIAAiQIAfAAIAAA1QAJgKAPABQATAAAKALQAJAKAAARIAAA+g");
	this.shape_2.setTransform(41.475,25.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgGA5QgJgJABgPIAAgqIgSAAIAAgaIAEAAQAQAAAAgQIAAgNIAaAAIAAAdIATAAIAAAaIgTAAIAAAlQAAAKALAAIAIgBIAAAZQgFADgLAAQgPAAgIgIg");
	this.shape_3.setTransform(31.4,26.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgfAyIAAhiIAeAAIAAANQAGgOASAAIAIABIAAAeIgJgBQgKAAgGAGQgGAHAAANIAAArg");
	this.shape_4.setTransform(24.3,27.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgjArQgJgIAAgNQAAgMAIgIQAIgHANgCIAWgDQAIgBAAgGQAAgFgEgDQgEgDgHAAQgGAAgFAFQgEAEgBAGIgagGQABgMAKgJQAMgMATAAQAXAAALAMQAKAKAAARIAAAvIABAQIgbAAIgBgLQgJAOgSAAQgQAAgJgKgAgDAJQgLACAAAJQAAALALAAQASAAAAgUIAAgFg");
	this.shape_5.setTransform(14.175,27.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AghAmQgQgPgBgXQAAgWAQgPQAPgPAVAAQAUAAANALQALAJAEAPIgcAIQgEgPgQAAQgIAAgHAHQgGAHAAAKQAAAMAHAGQAGAHAJAAQARAAADgPIAbAIQgDAOgMAKQgNALgTAAQgWAAgOgPg");
	this.shape_6.setTransform(3.35,27.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgjArQgJgIAAgNQAAgMAIgIQAIgHANgCIAWgDQAIgBAAgGQAAgFgEgDQgEgDgHAAQgGAAgFAFQgEAEgBAGIgagGQABgMAKgJQAMgMATAAQAXAAALAMQAKAKAAARIAAAvIABAQIgbAAIgBgLQgJAOgSAAQgQAAgJgKgAgDAJQgLACAAAJQAAALALAAQASAAAAgUIAAgFg");
	this.shape_7.setTransform(-7.925,27.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAxBHIAAhdIglBdIgYAAIglhcIAABcIgeAAIAAiNIApAAIAmBfIAlhfIArAAIAACNg");
	this.shape_8.setTransform(-22.725,25.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AghAnQgQgPAAgYQAAgWAQgPQAOgPATAAQAXAAAOAOQANANAAAYIgBAJIhEAAQAAAIAHAGQAHAFAIAAQAPAAAFgNIAZAHQgEAOgLAIQgNAKgSAAQgUAAgPgOgAAUgLQAAgHgEgEQgGgGgKAAQgHAAgGAGQgFAFAAAGIAmAAIAAAAg");
	this.shape_9.setTransform(-42.775,27.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAQBIIAAg4QAAgRgQAAQgGAAgFADQgEAFAAAHIAAA6IgfAAIAAiQIAfAAIAAA1QAJgKAPABQATAAAKALQAJAKAAARIAAA+g");
	this.shape_10.setTransform(-54.225,25.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgGA5QgJgJAAgPIAAgqIgSAAIAAgaIAGAAQAPAAAAgQIAAgNIAbAAIAAAdIATAAIAAAaIgTAAIAAAlQAAAKALAAIAIgBIAAAZQgHADgKAAQgPAAgIgIg");
	this.shape_11.setTransform(-64.3,26.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAQAzIAAg4QAAgRgQAAQgGAAgFAEQgEAFAAAIIAAA4IgfAAIAAhiIAeAAIAAALQADgHAJgDQAGgEAIAAQASAAAKAMQAJAKAAASIAAA9g");
	this.shape_12.setTransform(58.875,5.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgOBKIAAhjIAdAAIAABjgAgMgqQgFgGAAgHQAAgHAFgGQAFgFAHAAQAHAAAFAFQAGAGAAAHQAAAHgGAGQgFAFgHAAQgHAAgFgFg");
	this.shape_13.setTransform(50.025,2.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgkBFIAXg0IgqhVIAiAAIAXA2IAWg2IAgAAIg8CJg");
	this.shape_14.setTransform(36.425,7.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgGA5QgIgJAAgPIAAgqIgSAAIAAgaIAEAAQAQAAAAgQIAAgNIAaAAIAAAdIATAAIAAAaIgTAAIAAAlQABAKAKAAIAIgBIAAAZQgGADgJAAQgQAAgIgIg");
	this.shape_15.setTransform(26.65,3.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgOBKIAAhjIAdAAIAABjgAgMgqQgFgGAAgHQAAgHAFgGQAFgFAHAAQAHAAAFAFQAGAGAAAHQAAAHgGAGQgFAFgHAAQgHAAgFgFg");
	this.shape_16.setTransform(20.275,2.825);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAQAzIAAg4QAAgRgQAAQgGAAgFAEQgEAFAAAIIAAA4IgfAAIAAhiIAeAAIAAALQADgHAJgDQAGgEAIAAQASAAAKAMQAJAKAAASIAAA9g");
	this.shape_17.setTransform(11.525,5.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgkAnQgKgKAAgRIAAg+IAeAAIAAA4QAAAHAEAFQAEAFAIAAQAHAAAEgFQAFgFAAgHIAAg4IAeAAIAABRIABASIgdAAIgBgKQgHAMgTAAQgRAAgKgMg");
	this.shape_18.setTransform(-0.425,5.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAwAzIAAg4QAAgRgQAAQgIAAgEAFQgFAFAAAHIAAA4IgdAAIAAg4QAAgRgQAAQgHAAgFAFQgEAFAAAHIAAA4IgeAAIAAhiIAdAAIAAALQADgGAJgEQAIgEAIAAQAVAAAIAPQAKgPAUAAQAQAAAKAJQALAKAAATIAAA/g");
	this.shape_19.setTransform(-15.325,5.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAwAzIAAg4QAAgRgQAAQgIAAgEAFQgFAFAAAHIAAA4IgdAAIAAg4QAAgRgQAAQgHAAgFAFQgEAFAAAHIAAA4IgeAAIAAhiIAdAAIAAALQADgGAJgEQAIgEAIAAQAVAAAIAPQAKgPAUAAQAQAAAKAJQALAKAAATIAAA/g");
	this.shape_20.setTransform(-33.325,5.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AglAmQgPgPAAgXQAAgWAPgPQAPgPAWAAQAWAAAQAPQAPAPAAAWQAAAXgPAPQgQAPgWAAQgWAAgPgPgAgOgSQgIAHABALQgBAMAIAHQAGAGAIAAQAKAAAFgGQAIgHAAgMQAAgLgIgHQgFgGgKAAQgJAAgFAGg");
	this.shape_21.setTransform(-48.25,5.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgiAmQgPgPAAgXQAAgWAPgPQAPgPAVAAQATAAANALQANAJADAPIgbAIQgEgPgRAAQgIAAgGAHQgHAHAAAKQAAAMAHAGQAGAHAJAAQAQAAAFgPIAbAIQgEAOgMAKQgNALgTAAQgWAAgPgPg");
	this.shape_22.setTransform(-59.7,5.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgzBGIAAiJIAdAAIAAALQADgGAIgDQAIgEAJAAQAVAAANAPQAMAOAAAXQAAAWgNAPQgNAOgVAAQgSAAgIgKIAAAugAgPgkQgGAIAAALQAAAMAGAGQAHAGAIAAQAKAAAGgGQAHgGAAgMQAAgLgHgIQgGgFgKAAQgIAAgHAFg");
	this.shape_23.setTransform(63.775,-15.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgOBKIAAhjIAdAAIAABjgAgMgqQgFgGAAgHQAAgHAFgGQAFgFAHAAQAHAAAFAFQAGAGAAAHQAAAHgGAGQgFAFgHAAQgHAAgFgFg");
	this.shape_24.setTransform(54.375,-19.475);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAQBJIAAg6QAAgQgQAAQgGAAgFAEQgEAEAAAHIAAA7IgfAAIAAiRIAfAAIAAA0QAJgIAPgBQATAAAKAMQAJALAAAQIAAA/g");
	this.shape_25.setTransform(45.625,-19.35);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgeApQgJgIgBgLIAagFQAAAGAEADQAFAEAFAAQAMAAAAgIQAAgGgJgCIgLgDQgdgGgBgYQABgNAKgKQALgKAQAAQATAAALALQAJAIABALIgaAFQgBgNgNAAQgEAAgDADQgDACAAAEQAAAGAIABIAMADQAPADAIAIQAIAIAAALQAAAOgKAJQgLALgTAAQgUAAgLgMg");
	this.shape_26.setTransform(34.9,-17.075);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgjA8QgNgKgCgOIAagIQACAHAGAFQAFAFAJAAQAXAAAAgaIAAgFQgHAMgSAAQgUAAgNgOQgNgNAAgVQAAgUANgOQANgOAUAAQAUAAAGAMIAAgLIAdAAIAABXQAAAWgMAPQgOAQgaAAQgUAAgOgLgAgNgmQgHAGAAAKQAAALAGAFQAGAGAIAAQAKAAAGgGQAGgFAAgLQAAgKgHgGQgGgFgJAAQgHAAgGAFg");
	this.shape_27.setTransform(23.975,-15.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgjArQgJgIAAgNQAAgMAIgIQAIgHANgCIAWgDQAIgBAAgGQAAgFgEgDQgEgDgHAAQgGAAgFAFQgEAEgBAGIgagGQABgMAKgJQAMgMATAAQAXAAALAMQAKAKAAARIAAAvIABAQIgbAAIgBgLQgJAOgSAAQgQAAgJgKgAgDAJQgLACAAAJQAAALALAAQASAAAAgUIAAgFg");
	this.shape_28.setTransform(12.575,-17.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgOBJIAAiRIAdAAIAACRg");
	this.shape_29.setTransform(4.475,-19.35);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgRBJIAAhJIgQAAIAAgZIAQAAIAAgJQAAgRAKgKQAJgLASAAQAKAAAEACIAAAZIgJgBQgNAAAAANIAAAIIAWAAIAAAZIgWAAIAABJg");
	this.shape_30.setTransform(-2.025,-19.425);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAWAyIgVg/IgVA/IgfAAIgfhjIAgAAIAQA6IAUg6IAfAAIAUA6IAQg6IAeAAIgfBjg");
	this.shape_31.setTransform(-19.05,-17.075);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AghAnQgQgPAAgYQAAgWAQgPQAOgPATAAQAXAAAOAOQANANAAAYIgBAJIhEAAQAAAIAHAGQAHAFAIAAQAPAAAFgNIAZAHQgEAOgLAIQgNAKgSAAQgUAAgPgOgAAUgLQAAgHgEgEQgGgGgKAAQgHAAgGAGQgFAFAAAGIAmAAIAAAAg");
	this.shape_32.setTransform(-33.125,-17.075);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAQAzIAAg4QAAgRgQAAQgGAAgFAEQgEAGAAAHIAAA4IgfAAIAAhjIAeAAIAAAMQADgHAJgEQAGgDAIAAQASAAAKALQAJALAAARIAAA+g");
	this.shape_33.setTransform(-44.575,-17.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAlBHIgKgdIg2AAIgLAdIggAAIA1iNIAkAAIA1CNgAARAOIgRgxIgQAxIAhAAg");
	this.shape_34.setTransform(-62.8,-19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-77.7,-34,154.9,73.9), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgmBIIAYg2IgshZIAkAAIAYA4IAXg4IAiAAIg/CPg");
	this.shape.setTransform(72.775,11.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBMIAAiXIAfAAIAACXg");
	this.shape_1.setTransform(63.75,7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPBMIAAiXIAfAAIAACXg");
	this.shape_2.setTransform(57.75,7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgmAuQgJgJAAgOQABgNAIgIQAJgHANgCIAXgEQAJgBgBgGQAAgFgDgDQgFgDgHAAQgHAAgFAEQgEAFgBAGIgcgGQABgNALgKQANgLAUAAQAYAAAMAMQALAKgBASIAAAyIACAQIgdAAIgBgMQgKAPgSAAQgRAAgLgJgAgDAKQgMACAAAJQAAALAMAAQATAAgBgVIAAgEg");
	this.shape_3.setTransform(48.85,9.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggA1IAAhoIAfAAIAAAOQAGgPAUAAIAIABIAAAgIgKgBQgKAAgHAGQgGAIAAANIAAAug");
	this.shape_4.setTransform(39.575,9.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgmAqQgKgMAAgSIAAhBIAfAAIAAA7QAAAIAFAEQAEAGAIAAQAHAAAFgFQAEgFAAgIIAAg7IAhAAIAABWIABASIgfAAIgBgKQgIANgTgBQgTABgKgMg");
	this.shape_5.setTransform(28.6,9.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGA7QgKgIABgQIAAgsIgTAAIAAgcIAFAAQAQAAAAgRIAAgOIAcAAIAAAfIAUAAIAAAcIgUAAIAAAmQAAALAMAAIAIgBIAAAaQgGADgLAAQgQAAgIgJg");
	this.shape_6.setTransform(18.1,7.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgmAuQgJgJAAgOQAAgNAJgIQAIgHAOgCIAXgEQAJgBgBgGQAAgFgDgDQgFgDgHAAQgHAAgFAEQgEAFgBAGIgcgGQABgNALgKQANgLAUAAQAYAAAMAMQALAKAAASIAAAyIABAQIgdAAIgBgMQgJAPgUAAQgQAAgLgJgAgDAKQgMACAAAJQAAALAMAAQATAAgBgVIAAgEg");
	this.shape_7.setTransform(8.45,9.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARA1IAAg6QAAgTgRABQgHAAgFAEQgEAFAAAJIAAA6IggAAIAAhnIAfAAIAAAMQAEgHAJgEQAGgEAJAAQATAAAKANQAJAKAAATIAABAg");
	this.shape_8.setTransform(-3.25,9.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AggArQgJgJgBgLIAbgFQABAGAEAEQAEAEAHAAQAMAAAAgJQAAgHgKgCIgLgCQgfgHAAgZQAAgOALgKQALgKARAAQAUAAALALQAJAIABAMIgaAFQgCgNgNAAQgEAAgDACQgDADAAAEQAAAGAIACIANACQAQAEAIAIQAIAIAAAMQAAAPgKAJQgMALgUAAQgVAAgMgMg");
	this.shape_9.setTransform(-19.625,9.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_10.setTransform(-30.275,9.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAyA2IAAg8QAAgRgQAAQgIAAgFAFQgFAFAAAHIAAA8IgeAAIAAg8QAAgRgRAAQgIAAgFAFQgEAFAAAIIAAA7IggAAIAAhoIAeAAIAAAMQAEgGAJgFQAIgEAJAAQAWAAAIARQAMgRAUAAQARAAAKAKQAMAKAAAUIAABDg");
	this.shape_11.setTransform(-45.525,9.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgnAoQgQgQAAgYQAAgXAQgQQAQgPAXAAQAYAAAQAPQAQAQAAAXQAAAYgQAQQgQAPgYAAQgXAAgQgPgAgPgTQgIAHABAMQgBAMAIAIQAGAGAJAAQAKAAAGgGQAHgIAAgMQAAgMgHgHQgGgGgKAAQgJAAgGAGg");
	this.shape_12.setTransform(-61.2,9.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgkAoQgQgQAAgYQAAgXAQgQQAPgPAXAAQAUAAAOALQANAKADAPIgcAJQgFgQgRAAQgIAAgHAHQgIAHABALQAAAMAHAHQAHAHAJAAQARAAAFgQIAcAJQgEAPgNAKQgOALgTAAQgXAAgQgPg");
	this.shape_13.setTransform(-73.2,9.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_14.setTransform(45.275,-15.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgSBNIAAhNIgRAAIAAgbIARAAIAAgJQAAgSAKgLQAKgLATAAQAKAAAFACIAAAaIgKgBQgNAAAAAOIAAAIIAWAAIAAAbIgWAAIAABNg");
	this.shape_15.setTransform(35.625,-17.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgPBOIAAhoIAfAAIAABogAgMgtQgFgFgBgIQABgHAFgGQAGgGAGABQAIgBAFAGQAFAGAAAHQAAAIgFAFQgFAGgIAAQgGAAgGgGg");
	this.shape_16.setTransform(28.85,-17.75);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgPBMIAAiXIAfAAIAACXg");
	this.shape_17.setTransform(22.85,-17.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_18.setTransform(8.875,-15.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AggA1IAAhoIAfAAIAAAOQAGgPAUAAIAIABIAAAgIgKgBQgKAAgHAGQgGAIAAANIAAAug");
	this.shape_19.setTransform(-0.725,-15.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_20.setTransform(-11.275,-15.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AARBMIAAg8QAAgRgRAAQgGAAgFADQgFAGAAAHIAAA9IggAAIAAiXIAgAAIAAA3QAJgKARAAQATAAAKAMQAKALAAARIAABCg");
	this.shape_21.setTransform(-23.3,-17.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAgBLIgghiIgfBiIgiAAIgpiVIAjAAIAZBfIAfhfIAhAAIAfBfIAYhfIAiAAIgpCVg");
	this.shape_22.setTransform(-40.475,-17.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-84.1,-32.9,168,55.2), null);


(lib.Registerbtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgSAWQgJgIAAgOQAAgMAJgJQAIgJAKAAQANAAAIAJQAGAIAAANIAAADIgqAAQAAAIAFAFQAFAFAGAAQANAAADgMIAKADQgCAIgHAFQgHAGgKAAQgKAAgJgJgAAQgFQAAgHgEgEQgFgEgHAAQgGAAgEAFQgEAEAAAGIAeAAIAAAAg");
	this.shape.setTransform(34.45,0.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgPAdIAAg4IALAAIAAAKQAFgLAMAAIADAAIAAAMIgFAAQgOAAAAAQIAAAdg");
	this.shape_1.setTransform(29.4,0.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgVAWQgHgJgBgNQABgMAHgJQAJgJAMAAQANAAAIAJQAJAJAAAMQAAANgJAJQgIAJgNAAQgMAAgJgJgAgMgOQgFAFAAAJQAAAJAFAGQAFAFAHAAQAIAAAFgFQAFgGAAgJQAAgJgFgFQgFgGgIAAQgHAAgFAGg");
	this.shape_2.setTransform(23.5,0.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAfAeIAAgjQAAgOgMAAQgGAAgDAEQgFAFAAAGIAAAiIgKAAIAAgjQAAgOgMAAQgGAAgDAEQgFAEAAAHIAAAiIgKAAIAAg5IAKAAIAAAIQAGgKAMAAQAMAAAEALQAGgLANAAQAJAAAFAGQAHAGgBAKIAAAlg");
	this.shape_3.setTransform(15.05,0.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgPAdIAAg4IALAAIAAAKQAFgLAMAAIADAAIAAAMIgFAAQgOAAAAAQIAAAdg");
	this.shape_4.setTransform(5.1,0.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgVAWQgHgJgBgNQABgMAHgJQAJgJAMAAQANAAAIAJQAJAJAAAMQAAANgJAJQgIAJgNAAQgMAAgJgJgAgMgOQgFAFAAAJQAAAJAFAGQAFAFAHAAQAIAAAEgFQAGgGAAgJQAAgJgGgFQgEgGgIAAQgHAAgFAGg");
	this.shape_5.setTransform(-0.8,0.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgHAsIAAgvIgKAAIAAgKIAKAAIAAgKQABgKAFgEQAFgGAHAAQAFAAACABIAAAKIgEAAQgKAAAAAJIAAAKIAOAAIAAAKIgOAAIAAAvg");
	this.shape_6.setTransform(-6.25,-0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAMAsIgSgaIgIAIIAAASIgLAAIAAhXIALAAIAAA2IAYgYIAQAAIgZAXIAZAig");
	this.shape_7.setTransform(-13.875,-0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgSAWQgIgJAAgNQAAgNAIgIQAIgJAMAAQAKAAAHAGQAGAFACAIIgKAEQgDgMgMAAQgHAAgFAFQgFAFAAAJQAAAJAFAGQAFAFAHAAQAMAAAEgMIAKAFQgDAHgGAFQgHAGgKAAQgMAAgIgJg");
	this.shape_8.setTransform(-20.5,0.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgFAsIAAg5IAKAAIAAA5gAgFgdQgCgCAAgEQAAgDACgDQADgCACAAQADAAADACQACADAAADQAAAEgCACQgDACgDAAQgCAAgDgCg");
	this.shape_9.setTransform(-25.175,-0.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgFAsIAAhXIALAAIAABXg");
	this.shape_10.setTransform(-28.125,-0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgaAhQgNgNAAgUQAAgUANgMQAMgMAQAAQAPABAKAHQAKAHADAMIgLAFQgFgVgWAAQgLAAgJAJQgJAJAAAPQAAAQAJAJQAJAJALAAQALAAAHgHQAHgEADgKIAKAEQgEANgJAGQgKAJgPgBQgQAAgMgLg");
	this.shape_11.setTransform(-34.075,-0.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1).p("Al4hdILyAAQAnAAAbAbQAcAbAAAnQAAAngcAcQgbAbgnAAIryAAQgoAAgbgbQgcgcAAgnQAAgnAcgbQAcgbAnAAg");
	this.shape_12.setTransform(0.175,-0.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Registerbtn, new cjs.Rectangle(-48,-10.4,96.4,20.8), null);


(lib.planebyitself = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(5,1,1).p("As3GuQACgHABgKIABgdQAGg/ANgpQARg/A0gSQCMgzB+gvQBhgkE2h4QCDg0DqhjQEUhzCJg8QBGgfEjhyQEoh0BAgcQgBAGgGAHQgBACgKAJQg8A+ghAhQg8A8glAfQg7A0irCNQiXB+hTBEIkTDcQj5DIh9BjQhPA/goAfQhCAzg4AlQgoAagdALQgzASgjglQhqh4gvg0QhOhYgNgOQg0g2gwgoQgOgNgSgKQgYgNgTABQgXACgLAVQgHARgWAgQgUAdgEANQgFAPgQAXQgOAVgGAOgAwPhLIiGhSQiehhhMg1QgcgVgFgUQAJgHACgBQAHgEAHAAQDQgOD/gVQH+gqDsglQDNgfTHiWQAsgEABAAQAaABAQARQg/AVjJAxQjvA5gbAHIwOEXQjcA6gvAOQhiAbgxAOQhWAYg8AWQgnALgUAKQgkARgKAgQgKAgAlC+QASBeAUBYQAHAYAUALQAFABADgIQABgBAAgC");
	this.shape.setTransform(-0.025,0.0056);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.planebyitself, new cjs.Rectangle(-146.6,-69.6,293.2,139.2), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AljD/IAAn9ILGAAIAAH9g");
	mask.setTransform(35.55,25.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAFIAAgBQAAgHAGAAQAHAAAAAHIAAABg");
	this.shape.setTransform(17.625,25.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AACCsIk5jyQADACAFABQALACAHgIIBjhmQAOgMARACIHTBAQgNgBgHALIi6ELIgCADQgTAYgdADIgLABQgXAAgUgPgACUhLQgFAGAAAKIAAALQAAAKAGAGQAGAFAJAAQALAAAHgFIgDgLQgHAEgGAAQgKAAAAgKIAAgBIAcAAIAAgKQAAgJgFgGQgGgGgKAAQgJAAgGAGgABiggQAHAFAMAAQAJAAAFgFQAGgFAAgHQAAgLgNgEIgHgDQgEgBAAgDQAAgDAGAAQAFAAAHADIAGgKQgIgFgKAAQgJAAgGAFQgFAEAAAHQAAAMANAEIAGACQAFACAAACQAAAEgGAAQgIAAgGgEgAA3g3QgEAEAAAHQAAARAVAAQAIAAAMgFIAAggQAAgRgTAAQgKAAgJAEIABANQAHgEAIAAQAIAAAAAGIAAACIgJAAQgJAAgFAFgAAKhLQgFAGAAAKIAAALQAAAKAGAGQAGAFAJAAQALAAAIgFIgEgLQgGAEgHAAQgJAAAAgKIAAgBIAbAAIAAgKQAAgJgFgGQgGgGgJAAQgKAAgGAGgAgUgoQAAANANAAQAEAAAFgCIgBgLIgEABQgEAAAAgFIAAg3IgNAAgAhChMQgFAFAAAIIAAARQAAAIAFAFQAGAGAKAAQAIAAANgFIAAhDIgOAAIAAAUIgJgCQgJAAgFAFgAijhLQgGAGAAAKIAAALQAAAKAHAGQAGAFAJAAQAKAAAIgFIgEgLQgGAEgHAAQgJAAAAgKIAAgBIAbAAIAAgKQAAgJgFgGQgFgGgKAAQgKAAgFAGgAjDgoQAAANANAAQAFAAAGgCIgCgLIgEABQgEAAAAgFIAAg3IgOAAgAhdg8IAAAgIAOAAIAAgkQAAgRgUAAQgJAAgNAFIAAAwIAOAAIAAgnQADgCADAAQAIAAAAAJg");
	this.shape_1.setTransform(32.5125,32.3468);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgGAFIAAgBQAAgHAGAAQAHAAAAAHIAAABg");
	this.shape_2.setTransform(48.85,25.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgGAAQAAgFAGABIAHAAIAAAJIgGABQgHgBAAgFg");
	this.shape_3.setTransform(39.675,27.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGAFIAAgBQAAgHAGAAQAHAAAAAHIAAABg");
	this.shape_4.setTransform(35.075,25.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgGAGIAAgLQAAgJAHAAIAGACIAAAaIgFABQgIAAAAgJg");
	this.shape_5.setTransform(27.425,26.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ah4B8QgJgBgFgHQgGgIACgIIAfjLQACgMgHgJID8CRIhxgPQgSgDgMANIhjBmQgGAHgJAAIgDgBg");
	this.shape_6.setTransform(13.9839,12.4618);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ah4B8QgJgBgFgHQgGgIACgIIAfjLQACgMgHgJID8CRIhxgPQgSgDgMANIhjBmQgGAHgJAAIgDgBg");
	this.shape_7.setTransform(13.9839,12.4618);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAKhKQAGgHAIgBQAJgCAHAFQAFADADAGIAlBVQAEAKAKAFIjFA1g");
	this.shape_8.setTransform(61.225,28.9077);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAKhKQAGgHAIgBQAJgCAHAFQAFADADAGIAlBVQAEAKAKAFIjFA1g");
	this.shape_9.setTransform(61.225,28.9077);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,71.1,51), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmoGVIAAspINRAAIAAMpg");
	mask.setTransform(42.525,40.525);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AGeDtQhNgiiYgVIg2gEQiJAAiSANQimAPhiAZQgGACgCgHIAAgEQACgEADgBQBXgeBZgRQBlgVBmAAIAEgHQAHgPABgFQADgSgEgPQgEgSgLgLQgLgLgQgCQgRgCgiALQgQAGgLACQgXAFgTgFQgWgGgIgSIgBgCIgGABQgbgCgHgUQgFgNAJgJQAEgFALgHQAPgJgDgOIgEgIQgNgXAMgJQAIgFAMgBQAJgBADgBQAIgEAEgVIACgHQAEgZAMgIQANgIAWALIAHADQAQAGAegHQgBgGABgHQADgOAUgQIAJgIIgDgGIgCgIQgDgLAEgGQAEgIAJACQAIABADAGQAHAMgHANIgBADQAOAJARgCQAKgBAUgJIAUgHQARgGAKAIQALAJAAAcIAAAHQAAAUACAJQADAOAMAHQAKAFAJgHIAGgHQAKgNALgCQAKgCAGAFQAHAGAAANQgBAVAHAKIAGAHIACgBQAMgLANADQAIACACAIQADAHgFAGQgEAFgHACQgHACgFgBIgGgCQgCAHAEAFQAIAJARABQAaABAMAQQALAQABAUQAAANgFAMQgGAPgKAGQgNAIgPgHQgIgEgGgHQgIgHgEgCQgEgBgEABQgEABgFAIQgWAegogGQgKgBgXgLIgEgCQgQgIgLgDQgKgCgGADQgIADgDAHQgDAIACAIQAHATAEADQAFADgDAFQgCAFgGgCIAAAAQgMgEgFgTQgFgRADgLQADgNALgGQAMgIARAFIACAAQAJACAYALIABABQASAJALACQAPADAOgGQAGgDAJgKIAJgKQAFgFAIgCQAGgCAIADIACAAQAIAEAFAFIACACIANAJQAFACAFgBQAMgEAEgRQAEgOgEgPQgFgRgNgFQgEgDgMAAQgNAAgIgDQgRgIgDgQQgBgIACgIQgEgDgFgHQgLgPAAgPIABgIQABgJgCgCIgCgBQgGAAgHAHIgDAEQgNAOgMACQgOABgKgJQgRgPgBgfIAAgHQAAghgHgFQgEgCgGABIgUAIQgRAHgJACQgOAEgNgCQgNgCgLgIIgKAJQgUARACANQAcgHATAGQATAGAGAQQAFARgLAIQgHAFgMgCQgFAAgJgDQgLgDgMgIQgNgJgGgKQgfAIgSgFIgOgFQgKgFgEAAQgGgCgEAEQgGAFgEAVIgDAPQgGAQgIAGQgGAEgNABIgHABQgGACAAABQAAABAEAKIAFALQAIAbgcAPQgKAFgBAIQgBAFAGAFQAGAGAOABQAAgFADgEQADgGAIgBQAGgBAFAEQAHAGgCAIQgCAFgKAEIgCAAQAEAIAHAEQALAGATgCQARgBAQgFIADgBQAggLARgBQAdgBATASQARAQADAaQADAWgHAWIAAABIgFAMIAdABQBXAFBdAOIBxAEIB4AEQAGABAAAGQgBAHgGgBIh4gEIgQgBQBZATAwAVQAGACgDAGQgBAEgFAAgAjxC3Ig0ALQCbgXC9gFIhXgEQhqAAhjAVgADIhKIgEACQAIACACgDIAAgBIgCAAIgEAAgAhCiKQADAFAIAGQAGAEAFABIABABQAMAFAHABIAJgBIACgDQACgFgEgFQgIgMgVAAQgKAAgMADgAgvjaIABAGQACgFgCgEIAAgBg");
	this.shape.setTransform(42.525,23.7625);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0,0,85.1,47.5), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmoGVIAAspINRAAIAAMpg");
	mask.setTransform(42.525,40.525);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgiAmQgQgPABgWQgBgWAQgPQAPgQAVAAQATAAAQAOIgLAJQgKgKgOAAQgQAAgKANQgMALAAAQQAAAQAMALQAKAMAQAAQAOAAAJgIQAJgHAAgNIgdAAIAAgMIAtAAQAAAagNAOQgNANgWAAQgVAAgPgPg");
	this.shape.setTransform(28.35,59.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(23.3,54.4,10.099999999999998,10.600000000000001), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AmoGVIAAspINRAAIAAMpg");
	mask_1.setTransform(42.525,40.525);

	// Layer_3
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2E2E2E").s().p("AATA0IgagnIgNAAIAAAnIgPAAIAAhnIAnAAQAQAAAIAKQAHAKAAANQAAAMgGAIQgIAJgNABIAcAogAgUAAIAXAAQASAAgBgSQAAgTgQAAIgYAAg");
	this.shape_10.setTransform(52.6,59.7);

	var maskedShapeInstanceList = [this.shape_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(49.1,54.6,7.100000000000001,10.300000000000004), null);


(lib.Plane = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_17
	this.instance = new lib.planebyitself();
	this.instance.parent = this;
	this.instance.setTransform(-409.6,214.85,1,1,0,0,0,0.1,3.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Plane, new cjs.Rectangle(-556.3,142.1,293.19999999999993,139.20000000000002), null);


(lib.LEndlease = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.parent = this;
	this.instance.setTransform(0.05,0.15,1.4501,1.4501,0,0,0,35.6,25.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.LEndlease, new cjs.Rectangle(-51.5,-36.9,103.1,73.9), null);


(lib.FHhill = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol13();
	this.instance.parent = this;
	this.instance.setTransform(15.45,35.4);

	this.instance_1 = new lib.Symbol12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(5.25,35.4);

	this.instance_2 = new lib.Symbol11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-3.95,35.4);

	this.instance_3 = new lib.Symbol10();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-14.3,35.4);

	this.instance_4 = new lib.Symbol9();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-33.25,19.2);

	this.instance_5 = new lib.Symbol8();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-24.95,19.2);

	this.instance_6 = new lib.Symbol7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(33.2,19.2);

	this.instance_7 = new lib.Symbol6();
	this.instance_7.parent = this;
	this.instance_7.setTransform(21.9,19.2);

	this.instance_8 = new lib.Symbol5();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-1.85,19.2);

	this.instance_9 = new lib.ClipGroup_3();
	this.instance_9.parent = this;
	this.instance_9.setTransform(0,0,1,1,0,0,0,42.5,40.5);

	this.instance_10 = new lib.ClipGroup_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(0,0,1,1,0,0,0,42.5,40.5);

	this.instance_11 = new lib.ClipGroup_2();
	this.instance_11.parent = this;
	this.instance_11.setTransform(0,0,1,1,0,0,0,42.5,40.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.FHhill, new cjs.Rectangle(-42.5,-40.5,85.1,81.1), null);


// stage content:
(lib.FHhalf_page_300x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{lineout:72,"lineout":170,"lineout":268});

	// trace_idn
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2).p("ADkgkQgOACgMACQhIAMgiAGQhMALgjAGQhLANgkAGQgiAEhDAL");
	this.shape.setTransform(-19.7767,173.0122);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(2).p("AEHgqQg9AKgjAGQhIAMgiAGQhLAKgkAHQhLANgkAGQgiAEhDAL");
	this.shape_1.setTransform(-16.2777,172.4496);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(2).p("AEvgxQghAGgVAEQhQAMgqAHQhIANgiAFQhLAKgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_2.setTransform(-12.2662,171.764);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(2).p("AFSg3QgMACgJABQhFANgiAGQhQANgqAHQhIAMghAFQhMALgkAHQhLANgkAGQgiAEhDAL");
	this.shape_3.setTransform(-8.772,171.1255);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(2).p("AF0g+QgHABgHABQgFABgFACQgzAJgVADQhGANghAGQhRANgpAHQhHALgjAGQhLALgkAHQhLANgkAGQgiAEhEAL");
	this.shape_4.setTransform(-4.6054,170.431);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(2).p("AGZhFQgDAAgDABQgdAGg1AJQgGABgFACQgyAJgWADQhFANgiAGQhQANgqAGQhHAMgiAGQhMALgkAHQhLANgkAGQgiAEhDAL");
	this.shape_5.setTransform(-0.8554,169.7185);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(2).p("AG8hMQgmAHgmAHQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgpAGQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_6.setTransform(2.6446,169.0531);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(2).p("AHkhUQhNAQhPAOQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhPALgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_7.setTransform(6.6446,168.254);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(2).p("AIHhbQgaAFgcAGQhUAShYAQQgdAGg1AJQgGABgFACQgyAJgWADQhFANgiAFQhPANgqAHQhIAMgiAGQhMALgkAHQhLANgkAGQgiAEhDAL");
	this.shape_8.setTransform(10.1446,167.5435);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(2).p("AIrhiQg6AMhEANQhUAShYAQQgdAGg1AJQgGABgFACQgyAJgWADQhFAMghAGQhQANgqAHQhIAMgiAGQhMALgkAHQhLANgkAGQgiAEhDAL");
	this.shape_9.setTransform(13.7196,166.8185);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(2).p("AJMhpQhVAShrAVQhVAShXAQQgdAGg2AJQgFABgFACQgzAJgVADQhFAMghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEAL");
	this.shape_10.setTransform(17.0696,166.1185);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").ss(2).p("AJvhwQhsAYiSAdQhVAShXAQQgdAHg2AJQgFABgFABQgzAIgVAEQhFANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_11.setTransform(19.7535,165.3935);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(2).p("AKXh6QgQAEgRAFQh5Aci1AkQhVAShXAQQgdAGg2AJQgFAAgFACQgzAJgUADQhGANghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEAL");
	this.shape_12.setTransform(23.8511,164.4185);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FFFFFF").ss(2).p("AK7iEQg1ANg6AQQh5Aci1AkQhVAShXAQQgdAFg2AJQgFABgFACQgyAJgVADQhGANghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEAL");
	this.shape_13.setTransform(28.0946,163.4435);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(2).p("AKkh+Qg4APg+AQQh5Aci2AkQhUAShYAPQgdAGg1AJQgFABgFACQgyAJgWADQhFANgiAGQhQANgqAHQhIAMgiAGQhMALgkAHQhLANgkAGQgiAEhDALALZiMQgaAHgbAH");
	this.shape_14.setTransform(31.1196,162.6185);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FFFFFF").ss(2).p("AJghpQg5AQg/APQh5Aci2AkQhUARhYAQQgcAGg1AJQgGABgFACQgyAJgWADQhFANgiAGQhQANgqAHQhIAMgiAGQhMALgkAHQhLANgkAGQgiAEhDALAMfihQgaAIgcAJQhAAUhJAT");
	this.shape_15.setTransform(38.1446,160.5185);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(2).p("ANJixQg7AYhQAYQg/AUhKAUQg5APg/APQh5Adi1AiQhVAShWAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_16.setTransform(42.3696,158.9685);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FFFFFF").ss(2).p("AIPhIQg5APg/APQh5Adi1AiQhVAShWAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEALANvjEQgKAHgOAFQhJAkh2AkQg/AUhKAU");
	this.shape_17.setTransform(46.1696,157.2525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(2).p("AOAjMQgWAPgkAQQhIAkh2AkQg/AUhKAUQg5APg/APQh5Adi2AiQhUAShXAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_18.setTransform(47.8196,156.1935);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFFFFF").ss(2).p("AHcgaQg5APg/AOQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEALAOij3QgGASgNAQQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAU");
	this.shape_19.setTransform(51.2696,152.6563);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(2).p("AHZgPQg5APg/AOQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEALAOmkEQgCAegYAcQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAU");
	this.shape_20.setTransform(51.5946,151.5602);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FFFFFF").ss(2).p("AHZAeQg4AQhAAPQh5Aci1AkQhUAShXAQQgdAGg2AJQgFABgFACQgzAJgVADQhGANghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEALAODktQAQAWAJATQAYA4goAxQgVAYgdATQgWAPgjARQhJAkh2AkQg/AThKAT");
	this.shape_21.setTransform(51.5661,146.9244);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(2).p("AHZA8Qg4APhAAPQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEALANKlJQAMALAMAKQApApARAlQAYA3goAxQgVAYgdAUQgWAPgjAQQhJAkh2AjQg/AUhKAU");
	this.shape_22.setTransform(51.5661,143.9999);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FFFFFF").ss(2).p("AHZBKQg4APhAAPQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEALAMllXQAjAbAaAWQApApARAlQAYA3goAxQgVAYgdAUQgWAPgjAQQhJAkh2AjQg/AUhKAU");
	this.shape_23.setTransform(51.5661,142.5699);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(2).p("AHZBiQg4APhAAPQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEALALhlvQADADACACQAqAaAVARQAjAbAaAWQApApARAlQAYA3goAxQgVAYgdAUQgWAPgjAQQhJAjh2AkQg/AUhKAU");
	this.shape_24.setTransform(51.5661,140.1844);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FFFFFF").ss(2).p("AHZB1Qg4APhAAPQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEALAKqmAQAbASAhAXQAqAaAVARQAjAbAaAWQApApARAlQAYA3goAxQgVAYgdAUQgWAPgjAPQhJAkh2AkQg/AUhKAU");
	this.shape_25.setTransform(51.5661,138.2685);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(2).p("AHZB3Qg4APhAAQQh5Aci1AkQhUAShXAQQgdAGg2AJQgFABgFACQgzAJgVADQhGANghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEALAKjmCQAcATAnAaQAqAbAVARQAjAaAaAXQApAoARAlQAYA4goAxQgVAYgdATQgWAPgjAQQhJAkh2AkQg/AThKAU");
	this.shape_26.setTransform(51.5661,138.0435);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FFFFFF").ss(2).p("AJJmgQAYARAeAUQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA3goAxQgVAYgdATQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APhAAPQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_27.setTransform(51.5661,134.9935);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(2).p("AH0nEQAPARAWATQAFADAFAFQAmAcA2AkQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA3goAxQgVAXgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APhAAPQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_28.setTransform(51.5661,131.4685);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#FFFFFF").ss(2).p("AHtnJQAQAWAcAYQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA3goAwQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APhAAPQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_29.setTransform(51.5661,130.9685);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(2).p("AHVnrQgEAWAOAbQASAgAoAiQAnAfA/AoQAiAXBFAuQAqAbAVARQAjAaAaAXQApAoARAlQAYA4goAwQgVAYgdATQgWAPgjARQhJAkh2AkQg/AUhKATQg4AQhAAPQh5Aci1AkQhUAShXAQQgdAGg2AJQgFABgFACQgzAJgVADQhGANghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEAL");
	this.shape_30.setTransform(51.5661,127.5185);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#FFFFFF").ss(2).p("AHroAQgnAnAbA0QASAgAoAiQAnAfA/AoQAiAXBFAuQAqAbAVARQAjAaAaAXQApAoARAlQAYA3goAxQgVAYgdATQgWAPgjARQhJAkh2AkQg/AUhKATQg4AQhAAPQh5Aci1AkQhUAShXAQQgdAGg2AJQgFABgFACQgzAJgVADQhGANghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEAL");
	this.shape_31.setTransform(51.5661,125.4185);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(2).p("AINoMQgTAKgPAOQgnAnAbA0QASAgAoAiQAnAfA/AoQAiAXBFAuQAqAbAVARQAjAaAaAXQApAoARAlQAYA3goAxQgVAYgdATQgWAPgjARQhJAkh2AkQg/AUhKATQg4AQhAAPQh5Aci1AkQhUAShXAQQgdAGg2AJQgFABgFACQgzAJgVADQhGANghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEAL");
	this.shape_32.setTransform(51.5661,124.2185);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FFFFFF").ss(2).p("AJeobQgVAEgPAGQgzARgcAbQgnAnAbA0QASAgAoAiQAnAfA/AoQAiAXBFAuQAqAbAVARQAjAaAaAXQApAoARAlQAYA3goAxQgVAYgdATQgWAPgjARQhJAkh2AkQg/AThKAUQg4APhAAQQh5Aci1AkQhUAShXAQQgdAGg2AJQgFABgFACQgzAJgVADQhGANghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEAL");
	this.shape_33.setTransform(51.5661,122.7435);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(2).p("AKeoiQg/AKglAOQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APhAAPQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_34.setTransform(51.5661,122.0685);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#FFFFFF").ss(2).p("ALnomQggADgeAEQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APhAAPQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_35.setTransform(51.5661,121.5935);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(2).p("AMvopQgDAAgEAAQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APhAAPQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_36.setTransform(51.5661,121.3685);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FFFFFF").ss(2).p("AN1ooQgkgBgpABQhEADg7AJQhHALgoAOQgzARgcAbQgnAnAbA0QASAgAoAiQAnAfA/AoQAiAXBFAuQAqAbAVARQAjAaAaAXQApAoARAlQAYA3goAxQgVAYgdATQgWAPgjARQhJAkh2AkQg/AThKAUQg4APhAAQQh5Aci1AkQhUAShXAQQgdAGg2AJQgFABgFACQgzAJgVADQhGANghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEAL");
	this.shape_37.setTransform(51.5661,121.3435);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(2).p("AO9olQgSgCgEAAQg/gDhOABQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg5APg/APQh5Adi1AjQhUAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_38.setTransform(52.9861,121.356);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#FFFFFF").ss(2).p("APYoiQgJgBgKAAQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh2AkQhAAUhJAUQg5APg/APQh5Adi2AjQhTAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_39.setTransform(56.6446,121.356);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFFFFF").ss(2).p("AQCodQgPgBgLgBQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh2AkQg/AUhKAUQg5APg/APQh5Adi1AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_40.setTransform(59.9268,121.356);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FFFFFF").ss(2).p("AQroXQgVgCgLgCQgBAAgBAAQgxgCgZgCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh2AkQhAAUhJAUQg5APg/APQh5Adi1AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_41.setTransform(64.0301,121.356);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFFFFF").ss(2).p("ARLoRQgqgDgWgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg5APg/APQh5Adi0AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_42.setTransform(67.1802,121.356);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FFFFFF").ss(2).p("ARuoKIg+gFQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh2AkQhAAUhJAUQg5APg/APQh5Adi1AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_43.setTransform(70.7345,121.356);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFFFFF").ss(2).p("ASRoDIiEgMQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh2AkQg/AUhKAUQg5APg/APQh5Adi1AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_44.setTransform(74.2167,121.356);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FFFFFF").ss(2).p("AS9n6IjcgVQgwgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg5APg/APQh4Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_45.setTransform(78.5933,121.356);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FFFFFF").ss(2).p("ATfn0QgigDgSgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh2AkQg/AUhKAUQg5APg/APQh4Adi2AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_46.setTransform(82.0135,121.356);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FFFFFF").ss(2).p("AUBnrQgEAAgGAAQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg5APg/APQh4Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_47.setTransform(86.3696,121.356);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FFFFFF").ss(2).p("AUrnlIgTgDQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APg/APQh5Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_48.setTransform(89.6598,121.356);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FFFFFF").ss(2).p("AVLnfQgHAAgEAAIhIgJQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APg/APQh5Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_49.setTransform(92.8552,121.356);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FFFFFF").ss(2).p("AVynZQgUgBgWgCQgkgDgTAAIhIgJQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEAEg7AIQhHALgoAPQgzARgcAaQgmAnAaA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APg/APQh5Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_50.setTransform(97.5946,121.356);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#FFFFFF").ss(2).p("AWSnXQgygCg5gDQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQgmgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgbAaQgoAnAcA1QARAfAoAiQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh2AkQhAAUhIAUQg5APg/APQh5Adi2AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_51.setTransform(100.8446,121.356);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#FFFFFF").ss(2).p("AW6nWQgUAAghgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQgmgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgyARgcAaQgoAnAcA1QASAfAnAiQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh2AkQg/AUhJAUQg5APg/APQh5Adi2AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_52.setTransform(104.8196,121.356);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#FFFFFF").ss(2).p("AXinZQgeADgkAAQgTAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEAEg7AIQhHALgnAPQgzARgcAaQgnAnAbA1QASAfAoAiQAmAgA/AoQAiAXBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg+AUhKAUQg5APg/APQh5Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_53.setTransform(108.8696,121.356);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#FFFFFF").ss(2).p("AYDncQgNAAgSACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQgmgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgnAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA9AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh2AkQg/AUhJAUQg5APg/APQh5Adi2AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_54.setTransform(112.1446,121.356);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#FFFFFF").ss(2).p("AYnnpQgcAFgqAGQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQgmgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhGALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAiAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh1AkQhAAUhJAUQg5APg/APQh5Adi2AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_55.setTransform(115.7446,121.356);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#FFFFFF").ss(2).p("AZPn+QgEABgGADQgWAGgYAGQghAIg9AIQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQgmgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhGALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAjAXBEAuQApAaAWARQAjAbAZAWQApApASAlQAYA2gpAxQgUAYgdAUQgWAPgkAQQhIAkh1AkQhAAUhJAUQg5APg/APQh5Adi2AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_56.setTransform(119.7446,121.356);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#FFFFFF").ss(2).p("AZwoZQgjARgpAOQgWAGgYAGQgiAIg8AIQgNACgVACQgZABgJAAQgeADgkAAQgTAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEAEg6AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBEAuQAqAaAVARQAjAbAaAWQApApARAlQAYA2goAxQgVAYgdAUQgWAPgjAQQhJAkh1AkQg/AUhKAUQg5APg/APQh5Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_57.setTransform(123.0696,121.356);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#FFFFFF").ss(2).p("AaNoxQgCABgDADQg3AkhJAYQgWAGgYAGQgiAIg8AIQgNACgVACQgZABgJAAQgeADgkAAQgTAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhDAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQApAaAVARQAjAbAaAWQApApARAkQAYA3goAxQgVAYgdAUQgWAPgjAQQhIAkh2AkQg/AUhKAUQg5APg/APQh5Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_58.setTransform(125.8946,120.4935);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#FFFFFF").ss(2).p("AajpFQgYAWgaASQg3AkhJAYQgWAHgYAGQghAHg9AJQgMACgVABQgZABgJAAQgeAEgkAAQgUAAgwgCQg9AAhJgFQgkgCgTgBIhIgIQgKgBg3gDQgpgEgWgEQgmgDgTgCIjsgXQgwgEgYgDQgVgDgLgBQgygCgagDQgagBgqgCQg8gEgGAAQhAgDhNABQhDADg7AJQhHALgoAOQgzARgcAbQgoAnAcA0QASAgAoAiQAnAfA+AoQAjAXBFAuQAoAbAWARQAjAaAZAXQApAoASAkQAYA4gpAxQgUAYgdATQgWAPgkARQhHAkh2AkQg/AUhKATQg5AQg/APQh5Aci2AkQhUAShYAQQgdAGg1AJQgGABgFACQgyAJgWADQhFANgiAGQhQANgqAHQhIAMgiAGQhMALgkAHQhLANgkAGQgiAEhDAL");
	this.shape_59.setTransform(128.1196,118.8211);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#FFFFFF").ss(2).p("Aa8piQgGAIgGAHQglAwgxAiQg3AkhJAYQgWAGgYAGQghAIg9AIQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQgmgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhDAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAjAXBFAuQApAaAVARQAjAbAZAWQApAoASAlQAYA3gpAxQgUAYgdAUQgWAPgkAQQhHAkh2AkQg/AUhKAUQg5APg/APQh5Adi2AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_60.setTransform(130.41,116.0561);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#FFFFFF").ss(2).p("AbRqHQgZAygfAmQglAwgwAiQg3AkhJAYQgWAGgYAGQgiAIg8AIQgNACgVACQgZABgJAAQgeADgkAAQgTAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAuQAqAaAVARQAiAbAaAVQApApARAlQAYA3goAxQgVAYgdAUQgWAPgiAQQhJAkh2AkQg/AUhKAUQg5APg/APQh5Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQhRAMgpAHQhIANgjAFQhLALgkAHQhLAOgkAGQgiAEhEAL");
	this.shape_61.setTransform(132.6946,112.4985);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#FFFFFF").ss(2).p("AbhqtIgDAHQgOAogIAPQgcA7giArQglAwgxAiQg3AkhJAYQgWAGgYAGQghAIg9AIQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQgmgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhMABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAjAXBFAuQApAaAWARQAiAaAZAWQApApASAlQAYA3gpAxQgUAYgdAUQgWAPgjAQQhIAkh2AkQg/AUhKAUQg5APg/APQh5Adi2AjQhUAShYAQQgdAHg1AJQgGABgFABQgyAJgWAEQhFANgiAGQhQAMgqAHQhIANgiAFQhMALgkAHQhLAOgkAGQgiAEhDAL");
	this.shape_62.setTransform(134.2292,108.6965);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#FFFFFF").ss(2).p("AbzrbQgGAJgEARQgJAZAAACIgUAzQgOApgHAPQgdA6giArQglAxgwAhQg3AkhJAYQgWAHgYAGQgiAHg8AJQgNACgVABQgZABgJAAQgeAEgkAAQgTAAgwgCQg9AAhJgFQgkgCgTgBIhIgIQgLgBg3gDQgpgEgWgEQglgDgTgCIjtgXQgwgEgYgDQgUgDgMgBQgxgCgagDQgbgBgpgCQg8gEgHAAQg/gDhNABQhEADg7AJQhHALgoAOQgzARgcAbQgnAnAbA0QASAgAoAiQAnAfA/AoQAiAXBFAtQAqAbAVARQAjAaAZAXQApAoARAlQAYA4goAxQgVAYgdATQgVAPgjARQhJAkh2AkQg/AUhKATQg5AQg/APQh5Aci1AkQhVAShXAQQgdAGg2AJQgFABgFACQgzAJgVADQhGANghAGQhRANgpAHQhIAMgjAGQhLALgkAHQhLANgkAGQgiAEhEAL");
	this.shape_63.setTransform(135.9822,103.5185);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#FFFFFF").ss(2).p("AYTq2QgGAKgEAQQgJAaAAABIgUA0QgOAogHAPQgdA7giArQglAwgwAiQg3AkhJAYQgWAGgYAGQgiAIg8AIQgNACgVACQgZABgJAAQgeADgkAAQgTAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgxgCgagCQgagCgpgCQg8gEgHAAQg/gDhOABQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAXBFAtQAqAaAVARQAjAbAaAWQApApARAlQAYA3goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APhAAPQh5Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgzAJgVAEQhGANghAGQg7AJgmAG");
	this.shape_64.setTransform(158.3627,99.7875);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#FFFFFF").ss(2).p("AWqqkQgGAKgEAQQgJAaAAABIgUA0QgOAogHAPQgdA7giArQglAwgwAiQg3AkhJAYQgWAGgYAGQgiAIg8AIQgNACgVACQgZABgJAAQgeADgkAAQgTAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgTgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAWBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA3goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg4APhAAPQh5Adi1AjQhVAShXAQQgdAHg2AJQgFABgFABQgoAHgWAE");
	this.shape_65.setTransform(168.8627,97.9875);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#FFFFFF").ss(2).p("AV0qbQgGAKgEAQQgJAaAAABIgUA0QgOAogHAPQgdA7giArQglAwgwAiQg3AkhJAYQgWAGgYAGQgiAIg8AIQgNACgVACQgZABgJAAQgeADgkAAQgTAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgvgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEAEg7AIQhHALgoAPQgzARgcAaQgnAnAbA1QASAfAoAiQAnAgA/AoQAiAWBFAuQAqAaAVARQAjAbAaAWQApApARAlQAYA3goAxQgVAYgdAUQgWAPgjAQQhJAkh2AkQg/AUhKAUQg5APg/APQh5Adi1AjQhVAShXAQQgVAFgiAG");
	this.shape_66.setTransform(174.2738,97.0795);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#FFFFFF").ss(2).p("AULqGQgGAJgEARQgJAZAAACIgUAzQgOApgHAPQgdA6giArQglAxgwAhQg3AkhJAYQgWAHgYAGQgiAHg8AJQgNACgVABQgZABgJAAQgeAEgkAAQgTAAgwgCQg9AAhJgFQgkgCgTgBIhIgIQgLgBg3gDQgpgEgWgEQglgDgTgCIjsgXQgwgEgYgDQgUgDgMgBQgxgCgagDQgbgBgpgCQg8gEgHAAQg/gDhOABQhEADg7AJQhHALgoAOQgzARgcAbQgnAnAbA0QASAgAoAiQAnAfA/AnQAiAXBFAuQAqAbAVARQAjAaAaAXQApAoARAlQAYA4goAxQgVAYgdATQgWAPgjARQhJAkh2AkQg/AThKAUQg4APhAAQQh5Aci1AkQgIACgJAB");
	this.shape_67.setTransform(184.7593,95.025);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#FFFFFF").ss(2).p("ATZp8QgGAJgEARQgJAZAAACIgUAzQgOApgHAPQgdA6giArQglAxgwAhQg3AkhJAYQgWAHgYAGQgiAHg8AJQgNACgVABQgZABgJAAQgeAEgkAAQgTAAgwgCQg9AAhJgFQgkgCgTgBIhIgIQgLgBg3gDQgpgEgWgEQglgDgTgCIjsgXQgwgEgYgDQgUgDgMgBQgxgCgagDQgbgBgpgCQg8gEgHAAQg/gDhOABQhEADg7AJQhHALgoAOQgzARgcAbQgnAnAbA0QASAgAoAiQAnAfA/AnQAiAXBFAuQAqAbAVARQAjAaAaAXQApAoARAlQAYA4goAxQgVAYgdATQgWAPgjARQhJAkh2AkQg/AUhKATQg4AQhAAPQhcAWh/AZ");
	this.shape_68.setTransform(189.763,94.015);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#FFFFFF").ss(2).p("AQ6pYQgHAKgEAQQgJAaAAABIgTA0QgOAogIAPQgcA7giArQglAwgxAiQg3AkhJAYQgWAGgYAGQghAIg9AIQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQglgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAfA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA3gpAxQgUAYgdAUQgWAPgkAQQhIAkh2AkQhAAUhJAUQgKACgJAD");
	this.shape_69.setTransform(205.7377,90.375);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#FFFFFF").ss(2).p("AQ3o5QgHAKgEAQQgJAaAAABIgTA0QgOAogIAPQgcA7giArQglAwgxAiQg3AkhJAYQgWAGgYAGQghAIg9AIQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQglgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAhQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA3gpAxQgUAYgdAUQgWAPgkAQQg3AchRAb");
	this.shape_70.setTransform(206.0483,87.2614);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#FFFFFF").ss(2).p("AQ3oBQgHAKgEAQQgJAaAAABIgTA0QgOAogIAPQgcA7giArQglAwgxAiQg3AkhJAYQgWAGgYAGQghAIg9AIQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQglgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA0QASAfAoAiQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQAYA3gpAxQgIAJgJAJ");
	this.shape_71.setTransform(206.0483,81.675);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#FFFFFF").ss(2).p("AQ3nKQgHAKgEAQQgJAaAAABIgTA0QgOAogIAPQgcA7giArQglAwgxAiQg3AkhJAYQgWAGgYAGQghAIg9AIQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQglgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAmAcA1QASAfAoAiQAnAgA+AoQAjAXBFAuQApAaAWARQAjAbAZAWQApApASAlQACAGACAG");
	this.shape_72.setTransform(206.0483,76.175);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#FFFFFF").ss(2).p("AQ3l/QgHAKgEAQQgJAaAAABIgTA0QgOAogIAPQgcA7giArQglAwgxAiQg3AkhJAXQgWAGgYAGQghAIg9AIQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQglgDgTgCIjsgVQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAOQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQAjAXBFAuQAcASATAO");
	this.shape_73.setTransform(206.0483,68.675);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#FFFFFF").ss(2).p("AQ3lWQgHAKgEAQQgJAaAAABIgTA0QgOAogIAPQgcA7giArQglAwgxAhQg3AkhJAYQgWAGgYAGQghAIg9AIQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQglgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgoAnAcA1QASAfAoAiQAnAgA+AoQANAIATAN");
	this.shape_74.setTransform(206.0483,64.591);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#FFFFFF").ss(2).p("AQ2jqQgHAKgEAQQgJAaAAABIgTA0QgOAogIAPQgcA7giAqQglAwgxAiQg3AkhJAYQgWAGgYAGQghAIg9AIQgMACgVACQgZABgJAAQgeADgkAAQgUAAgwgBQg9gBhJgEQgkgDgTAAIhIgJQgKAAg3gDQgpgFgWgEQglgDgTgCIjsgWQgwgFgYgDQgVgCgLgCQgygCgagCQgagCgqgCQg8gEgGAAQhAgDhNABQhEAEg7AIQhHALgoAPQgzARgcAaQgTATgDAV");
	this.shape_75.setTransform(206.1002,53.7619);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#FFFFFF").ss(2).p("AQBjbQgGAKgEAQQgJAaAAABIgUA0QgOAogHAPQgdA7giAqQglAwgwAiQg3AkhJAYQgWAGgYAGQgiAIg8AIQgNACgVABQgZACgJAAQgeADgkAAQgTAAgwgBQg9gBhJgEQgkgDgTgBIhIgIQgLAAg3gDQgogFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgxgCgagCQgbgCgpgCQg8gEgHAAQg/gDhOABQhEADg7AJQhDAKgoAO");
	this.shape_76.setTransform(211.3627,52.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#FFFFFF").ss(2).p("AL9jbQgGAKgEAQQgJAaAAABIgUA0QgOAogHAPQgdA7giAqQglAwgwAiQg3AkhJAYQgWAGgYAGQgiAIg8AIQgNACgVABQgZACgJAAQgeADgkAAQgTAAgwgBQg9gBhIgEQgkgDgTgBIhIgIQgLAAg3gDQgpgFgWgEQglgDgTgCIjtgWQgwgFgYgDQgUgCgMgCQgogCgZgB");
	this.shape_77.setTransform(237.3627,52.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#FFFFFF").ss(2).p("AIWjbQgGAKgEAQQgJAaAAABIgUA0QgOAogHAPQgdA7giAqQglAwgwAiQg3AkhJAYQgWAGgYAGQgiAIg8AIQgNACgVABQgYACgJAAQgeADgkAAQgTAAgwgBQg9gBhJgEQgkgDgTgBIhIgIQgLAAg3gDQgpgFgWgE");
	this.shape_78.setTransform(260.4627,52.3);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#FFFFFF").ss(2).p("AGCjbQgHAKgEAQQgJAaAAABIgTA0QgOAogIAPQgcA7giAqQglAwgxAiQg3AkhJAYQgWAGgYAGQggAIg9AIQgMACgVABQgZACgJAAQgeADgkAAQgUAAgwgBQgvgBg2gD");
	this.shape_79.setTransform(275.3363,52.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#FFFFFF").ss(2).p("ADnjWQgGAJgEARQgJAZAAACIgUAzQgOApgHAPQgdA5giArQglAxgwAhQg2AkhJAYQgWAHgYAGQggAHg3AI");
	this.shape_80.setTransform(290.7911,51.8449);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#FFFFFF").ss(2).p("ACJi+QgGAKgEAQQgJAaAAABIgUA0QgOAogHAPQgdA6giArQgkAwgwAiQggAVgnAR");
	this.shape_81.setTransform(300.1605,49.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},9).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},2).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[]},1).to({state:[{t:this.shape}]},15).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},2).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[]},1).to({state:[{t:this.shape}]},15).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},2).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).wait(1));

	// PLANE
	this.PLANE_ANIMATION = new lib.Plane();
	this.PLANE_ANIMATION.name = "PLANE_ANIMATION";
	this.PLANE_ANIMATION.parent = this;
	this.PLANE_ANIMATION.setTransform(-23.25,172.45,0.4002,0.4,0,0,0,-409.4,212.2);
	this.PLANE_ANIMATION.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.PLANE_ANIMATION).to({regX:-409.3,x:19.85,y:163.05,alpha:1},6).to({regX:-409.6,regY:211.5,guide:{path:[20,163.1,25.3,162.4,30.3,161.6,51.5,158.4,67.3,155.3,80.1,152.8,91.9,150,135,139.7,166.1,124.2,173.9,120.3,175.3,116.1,176.7,111.8,172.6,106.3,168.8,101.1,158.7,93,153.1,88.5,135.4,74.7,128.7,69.6,126.5,65.8,124.3,61.9,126.7,59.4,130.8,54.7,150.2,53.7,167,53,197.2,55.1,219.3,56.6,259,60.5,270.4,61.7,280.3,61.6,318.9,61.1,336.6,42.1,343.6,34.6,346.6,25.1,348.1,20.5,348.1,17.2]}},66).to({alpha:0},5).to({_off:true},20).wait(1).to({_off:false,regX:-409.4,regY:212.2,x:-23.25,y:172.45},0).to({regX:-409.3,x:19.85,y:163.05,alpha:1},6).to({regX:-409.6,regY:211.5,guide:{path:[20,163.1,25.3,162.4,30.3,161.6,51.5,158.4,67.3,155.3,80.1,152.8,91.9,150,135,139.7,166.1,124.2,173.9,120.3,175.3,116.1,176.7,111.8,172.6,106.3,168.8,101.1,158.7,93,153.1,88.5,135.4,74.7,128.7,69.6,126.5,65.8,124.3,61.9,126.7,59.4,130.8,54.7,150.2,53.7,167,53,197.2,55.1,219.3,56.6,259,60.5,270.4,61.7,280.3,61.6,318.9,61.1,336.6,42.1,343.6,34.6,346.6,25.1,348.1,20.5,348.1,17.2]}},66).to({alpha:0},5).to({_off:true},20).wait(1).to({_off:false,regX:-409.4,regY:212.2,x:-23.25,y:172.45},0).to({regX:-409.3,x:19.85,y:163.05,alpha:1},6).to({regX:-409.6,regY:211.5,guide:{path:[20,163.1,25.3,162.4,30.3,161.6,51.5,158.4,67.3,155.3,80.1,152.8,91.9,150,135,139.7,166.1,124.2,173.9,120.3,175.3,116.1,176.7,111.8,172.6,106.3,168.8,101.1,158.7,93,153.1,88.5,135.4,74.7,128.7,69.6,126.5,65.8,124.3,61.9,126.7,59.4,130.8,54.7,150.2,53.7,167,53,197.2,55.1,219.3,56.6,259,60.5,270.4,61.7,280.3,61.6,318.9,61.1,336.6,42.1,343.6,34.6,346.6,25.1,348.1,20.5,348.1,17.2]}},66).to({alpha:0},5).wait(12));

	// Layer_20 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3bRbMAAAgi1MAu3AAAMAAAAi1g");
	mask.setTransform(150,87.55);

	// IMG2
	this.instance = new lib.Tween5("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(82,58);

	this.instance_1 = new lib.Tween6("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(82,247);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,y:247},90).wait(195));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:false},90).to({y:273.5,alpha:0},6).to({_off:true},1).wait(188));

	// IMG1
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(50,138);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(173,138);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(88).to({_off:false},0).to({_off:true,x:173},88).wait(109));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(88).to({_off:false},88).to({x:250,alpha:0},9).to({_off:true},1).wait(99));

	// IMG3
	this.instance_4 = new lib.Tween7("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(179,111.85);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween8("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(121,111.85);

	var maskedShapeInstanceList = [this.instance_4,this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},178).to({state:[{t:this.instance_5}]},106).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(178).to({_off:false},0).to({_off:true,x:121},106).wait(1));

	// TEXT_3
	this.instance_6 = new lib.Symbol2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(150.15,337.75,1.232,1.232);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(189).to({_off:false},0).to({y:391.3,alpha:1},7,cjs.Ease.cubicOut).wait(82).to({y:451.9,alpha:0},6,cjs.Ease.cubicIn).wait(1));

	// TEXT_2
	this.instance_7 = new lib.Symbol3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(150.35,323.75,1.232,1.232);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(94).to({_off:false},0).to({y:377.3,alpha:1},8,cjs.Ease.cubicOut).wait(81).to({y:437.9,alpha:0},6,cjs.Ease.cubicIn).to({_off:true},1).wait(95));

	// TEXT_1
	this.instance_8 = new lib.Symbol4();
	this.instance_8.parent = this;
	this.instance_8.setTransform(151.55,334.75,1.232,1.232);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({y:388.3,alpha:1},13,cjs.Ease.cubicOut).wait(73).to({y:448.9,alpha:0},7,cjs.Ease.cubicIn).to({_off:true},5).wait(187));

	// FH_hill_logo
	this.instance_9 = new lib.FHhill();
	this.instance_9.parent = this;
	this.instance_9.setTransform(150.2,268.1,1.2933,1.2896,0,0,0,0.4,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(285));

	// Lenmdlease_logo
	this.instance_10 = new lib.LEndlease();
	this.instance_10.parent = this;
	this.instance_10.setTransform(150,527.9,0.7478,0.7478);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(285));

	// Layer_1
	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgEAEQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAAAAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQABAAAAgBQABAAABAAQAAAAAAAAQAAAAABAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABQAAAAABAAQAAABAAABQAAAAAAAAQAAAAAAABQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAgBAAQAAAAgBgBQAAAAgBgBg");
	this.shape_82.setTransform(284.725,586.325);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgNARQgHgHAAgKQAAgJAHgHQAGgGAHAAQAKAAAGAGQAFAGAAAKIAAADIggAAQAAAFAEADQAEAEAEAAQAJAAADgJIAIADQgCAGgFAEQgGAEgHAAQgIAAgGgGgAAMgEQAAgEgDgEQgDgDgGABQgEAAgDADQgDADgBAEIAXAAIAAAAg");
	this.shape_83.setTransform(280.825,584.75);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgNAbQgGgFgBgHIAJgCQAAAFADADQADADAFAAQANAAAAgOIAAgGQgEAHgJAAQgIAAgGgGQgGgFAAgJQAAgJAGgGQAFgGAJAAQAJAAAEAGIAAgGIAIAAIAAAnQAAAKgFAFQgFAHgLAAQgIAAgFgEgAgIgTQgDADAAAHQAAAGADADQAEAEAFAAQAFAAADgEQAEgDAAgGQAAgHgEgDQgDgEgFAAQgFAAgEAEg");
	this.shape_84.setTransform(275.475,585.625);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AAKAWIAAgZQAAgLgKAAQgEAAgDAEQgCADAAAFIAAAYIgJAAIAAgqIAJAAIAAAGQAEgHAIAAQAIAAAEAFQAEAEAAAIIAAAag");
	this.shape_85.setTransform(270.325,584.675);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgOATQgDgEAAgFQAAgFADgEQAEgCAGgBIAKgCQABAAABAAQAAgBABAAQAAAAAAgBQABAAAAgBQAAgEgDgCQgCgCgEAAQgEAAgCACQgDADAAAEIgIgCQAAgHAFgDQAFgEAGAAQAJAAAFAFQAEAEAAAHIAAAUIABAHIgIAAIgBgGQgFAIgIAAQgHAAgEgEgAgDADQgGABAAAGQAAAAAAABQAAAAAAABQABAAAAABQAAABABAAQACABADAAQAMAAAAgMIAAgCg");
	this.shape_86.setTransform(265.15,584.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AAKAgIAAgaQAAgKgKABQgEAAgCADQgDACAAAFIAAAZIgJAAIAAg/IAJAAIAAAbQAEgHAIAAQAIAAAEAFQAEAFAAAGIAAAbg");
	this.shape_87.setTransform(260.175,583.65);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgNARQgHgIAAgJQAAgJAHgGQAGgHAIAAQAIAAAFAFQAFADABAGIgHADQgDgKgJABQgEgBgEAEQgEAFAAAGQAAAHAEAEQAEAEAEAAQAKAAACgJIAIAEQgCAFgFAEQgFAEgIAAQgIAAgGgGg");
	this.shape_88.setTransform(255.075,584.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgPAaQgFgGAAgKQAAgJAGgGQAFgGAJAAQAKgBADAIIAAgcIAIAAIAAA4IAAAIIgIAAIAAgGIAAAAQgEAHgJAAQgJAAgGgHgAgIAAQgDADAAAHQAAAHADAEQADAFAFAAQAGgBADgEQAEgEAAgHQAAgGgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_89.setTransform(247.225,583.7);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AAKAWIAAgZQAAgLgKAAQgEAAgDAEQgCADAAAFIAAAYIgJAAIAAgqIAJAAIAAAGQAEgHAIAAQAIAAAEAFQAEAEAAAIIAAAag");
	this.shape_90.setTransform(242.075,584.675);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgOATQgDgEAAgFQAAgFADgEQAEgCAFgBIALgCQABAAABAAQAAgBABAAQAAAAAAgBQABAAAAgBQAAgEgCgCQgDgCgEAAQgEAAgDACQgCADAAAEIgIgCQAAgHAFgDQAFgEAGAAQAJAAAFAFQAEAEAAAHIAAAUIABAHIgIAAIgBgGQgFAIgIAAQgHAAgEgEgAgDADQgGABAAAGQAAAAAAABQAAAAAAABQABAAAAABQAAABABAAQACABADAAQAMAAAAgMIAAgCg");
	this.shape_91.setTransform(236.9,584.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgDAgIAAg/IAHAAIAAA/g");
	this.shape_92.setTransform(230.825,583.65);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgOATQgDgEAAgFQAAgFADgEQADgCAGgBIAMgCQAAAAABAAQAAgBABAAQAAAAAAgBQABAAAAgBQAAgEgCgCQgDgCgEAAQgEAAgDACQgCADAAAEIgIgCQAAgHAFgDQAFgEAGAAQAKAAAEAFQAEAEAAAHIAAAUIABAHIgJAAIAAgGQgEAIgJAAQgGAAgFgEgAgDADQgGABAAAGQAAAAAAABQAAAAAAABQABAAAAABQAAABABAAQACABADAAQAMAAAAgMIAAgCg");
	this.shape_93.setTransform(227.1,584.75);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgDAWIgSgrIAKAAIALAhIAMghIAKAAIgSArg");
	this.shape_94.setTransform(222.375,584.725);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgPARQgGgHAAgKQAAgJAGgGQAGgHAJAAQAKAAAGAHQAGAGAAAJQAAAKgGAHQgGAGgKAAQgJAAgGgGgAgIgLQgEAFAAAGQAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHQAAgGgEgFQgDgEgGABQgFgBgDAEg");
	this.shape_95.setTransform(217.375,584.75);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgLAWIAAgqIAIAAIAAAIQAEgJAIAAIADABIAAAIIgEAAQgLAAAAAMIAAAWg");
	this.shape_96.setTransform(213.2,584.7);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgVAfIAAg8IAJAAIAAAHQAEgIAKAAQAJAAAFAHQAGAGgBAKQABAJgGAGQgFAHgKAAQgIAAgFgHIAAAXgAgIgSQgEAEAAAHQAAAHAEADQADAEAFAAQAGAAADgEQAEgDgBgHQABgHgEgEQgDgEgGAAQgFAAgDAEg");
	this.shape_97.setTransform(208.65,585.525);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgVAfIAAg8IAJAAIAAAHQAEgIAKAAQAJAAAFAHQAFAGAAAKQAAAJgFAGQgFAHgKAAQgIAAgFgHIAAAXgAgIgSQgEAEAAAHQAAAHAEADQADAEAFAAQAGAAADgEQADgDAAgHQAAgHgDgEQgDgEgGAAQgFAAgDAEg");
	this.shape_98.setTransform(203.15,585.525);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgNATQgFgEAAgFQAAgFAFgEQACgCAHgBIALgCQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAgEgCgCQgCgCgFAAQgDAAgDACQgCADgBAEIgIgCQABgHAFgDQAFgEAGAAQAJAAAFAFQAEAEAAAHIAAAUIAAAHIgIAAIAAgGQgFAIgIAAQgGAAgEgEgAgCADQgHABAAAGQAAAAAAABQAAAAABABQAAAAAAABQABABAAAAQACABADAAQALAAAAgMIAAgCg");
	this.shape_99.setTransform(197.7,584.75);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgNAbQgGgFgBgHIAJgCQAAAFADADQADADAFAAQANAAAAgOIAAgGQgEAHgJAAQgIAAgGgGQgGgFAAgJQAAgJAGgGQAFgGAJAAQAJAAAEAGIAAgGIAIAAIAAAnQAAAKgFAFQgFAHgLAAQgIAAgFgEgAgIgTQgDADAAAHQAAAGADADQAEAEAFAAQAFAAADgEQAEgDAAgGQAAgHgEgDQgDgEgFAAQgFAAgEAEg");
	this.shape_100.setTransform(190.025,585.625);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AAKAWIAAgZQAAgLgKAAQgEAAgDAEQgCADAAAFIAAAYIgJAAIAAgqIAJAAIAAAGQAEgHAIAAQAIAAAEAFQAEAEAAAIIAAAag");
	this.shape_101.setTransform(184.875,584.675);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgEAhIAAgqIAIAAIAAAqgAgEgWQAAAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQABAAAAgBQAAgBAAAAQABAAABgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQABAAAAABQAAABABAAQAAABAAAAQAAABAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAQgBAAAAgBQgBAAgBgBg");
	this.shape_102.setTransform(181,583.6);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AAKAWIAAgZQAAgLgKAAQgEAAgDAEQgCADAAAFIAAAYIgJAAIAAgqIAJAAIAAAGQAEgHAIAAQAIAAAEAFQAEAEAAAIIAAAag");
	this.shape_103.setTransform(177.175,584.675);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AAKAWIAAgZQAAgLgKAAQgEAAgDAEQgCADAAAFIAAAYIgJAAIAAgqIAJAAIAAAGQAEgHAIAAQAIAAAEAFQAEAEAAAIIAAAag");
	this.shape_104.setTransform(171.925,584.675);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgNATQgFgEAAgFQAAgFAFgEQACgCAHgBIAKgCQABAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAgEgCgCQgCgCgFAAQgDAAgCACQgDADgBAEIgIgCQABgHAFgDQAFgEAGAAQAJAAAFAFQAEAEAAAHIAAAUIAAAHIgIAAIAAgGQgEAIgJAAQgGAAgEgEgAgCADQgHABAAAGQAAAAAAABQAAAAABABQAAAAAAABQABABAAAAQACABADAAQALAAAAgMIAAgCg");
	this.shape_105.setTransform(166.75,584.75);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgDAgIAAg/IAHAAIAAA/g");
	this.shape_106.setTransform(163.125,583.65);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgUAfIAAg8IAIAAIAAAHQAEgIAJAAQAKAAAFAHQAGAGgBAKQABAJgGAGQgGAHgJAAQgJAAgEgHIAAAXgAgJgSQgDAEAAAHQAAAHADADQAEAEAFAAQAFAAAEgEQADgDAAgHQAAgHgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_107.setTransform(159.35,585.525);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgPARQgGgHAAgKQAAgJAGgGQAGgHAJAAQAKAAAGAHQAGAGAAAJQAAAKgGAHQgGAGgKAAQgJAAgGgGgAgIgLQgEAFAAAGQAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHQAAgGgEgFQgDgEgGABQgFgBgDAEg");
	this.shape_108.setTransform(151.325,584.75);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AAAAZQgEgDAAgGIAAgWIgIAAIAAgIIACAAQAHAAAAgHIAAgHIAGAAIAAAOIAKAAIAAAIIgKAAIAAAVQAAAGAHAAIADAAIAAAHIgGABQgFAAgCgEg");
	this.shape_109.setTransform(146.9,584.075);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgBAZQgDgDAAgGIAAgWIgIAAIAAgIIACAAQAHAAAAgHIAAgHIAHAAIAAAOIAJAAIAAAIIgJAAIAAAVQAAAGAFAAIAEAAIAAAHIgGABQgGAAgCgEg");
	this.shape_110.setTransform(141.1,584.075);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgNARQgHgIAAgJQAAgJAHgGQAGgHAIAAQAIAAAFAFQAFADABAGIgHADQgDgKgJABQgEgBgEAEQgEAFAAAGQAAAHAEAEQAEAEAEAAQAKAAACgJIAIAEQgCAFgFAEQgFAEgIAAQgIAAgGgGg");
	this.shape_111.setTransform(137.075,584.75);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgNARQgHgHAAgKQAAgJAHgHQAGgGAHAAQAKAAAGAGQAFAGAAAKIAAADIggAAQAAAFAEADQAEAEAEAAQAJAAADgJIAIADQgCAGgFAEQgGAEgHAAQgIAAgGgGgAAMgEQAAgEgDgEQgDgDgGABQgEAAgDADQgDADgBAEIAXAAIAAAAg");
	this.shape_112.setTransform(132.025,584.75);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgJAqIAAgIIADABQAGAAAAgHIAAgvIAHAAIAAAwQAAAGgCADQgEAEgEAAIgGAAgAAAgfQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAAAQABgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAABAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQABAAAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_113.setTransform(127.95,584.525);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgMAaIAAAGIgJAAIAAhAIAJAAIAAAcQACgDADgCQAFgCAEAAQAJgBAFAHQAGAFgBAKQABAKgGAGQgFAHgKAAQgIAAgFgHgAgIAAQgEADAAAHQAAAHAEAEQADAFAFAAQAGAAADgFQAEgEgBgHQABgHgEgDQgDgEgGAAQgFAAgDAEg");
	this.shape_114.setTransform(124.5,583.7);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgNARQgFgEAAgIIAAgaIAJAAIAAAZQAAAEACAEQADADAEAAQAEAAADgDQADgDAAgFIAAgZIAIAAIAAAiIAAAIIgIAAIAAgFQgDAGgIABQgIAAgEgGg");
	this.shape_115.setTransform(118.95,584.8);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AgQAbQgFgFgBgIIAJgDQAAAGAEAEQAEAEAFAAQAHAAADgDQAEgDAAgEQAAgIgJgCIgJgCQgHgBgEgEQgEgEAAgHQgBgIAHgGQAGgFAHAAQALAAAFAFQAFAEACAGIgIADQgBgEgEgDQgDgEgGAAQgFAAgDADQgDADAAAFQgBAHAJACIAIACQAIACAEAEQAFAEAAAHQAAAIgGAFQgHAGgJAAQgKAAgHgGg");
	this.shape_116.setTransform(113.55,583.725);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgEAEQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAAAAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQABAAAAgBQABAAABAAQAAAAAAAAQAAAAABAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABQAAAAABAAQAAABAAABQAAAAAAAAQAAAAAAABQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAgBAAQAAAAgBgBQAAAAgBgBg");
	this.shape_117.setTransform(107.025,586.325);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgOAfIALgXIgSgmIAJAAIAMAeIAOgeIAJAAIgbA9g");
	this.shape_118.setTransform(103.2,585.625);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgDAgIAAg/IAHAAIAAA/g");
	this.shape_119.setTransform(99.525,583.65);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AAKAWIAAgZQAAgLgKAAQgEAAgDAEQgCADAAAFIAAAYIgJAAIAAgqIAJAAIAAAGQAEgHAIAAQAIAAAEAFQAEAEAAAIIAAAag");
	this.shape_120.setTransform(95.725,584.675);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgPARQgGgHAAgKQAAgJAGgGQAGgHAJAAQAKAAAGAHQAGAGAAAJQAAAKgGAHQgGAGgKAAQgJAAgGgGgAgIgLQgEAFAAAGQAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHQAAgGgEgFQgDgEgGABQgFgBgDAEg");
	this.shape_121.setTransform(90.425,584.75);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AAKAWIAAgZQAAgLgKAAQgEAAgDAEQgCADAAAFIAAAYIgJAAIAAgqIAJAAIAAAGQAEgHAIAAQAIAAAEAFQAEAEAAAIIAAAag");
	this.shape_122.setTransform(82.725,584.675);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgPARQgGgHAAgKQAAgJAGgGQAGgHAJAAQAKAAAGAHQAGAGAAAJQAAAKgGAHQgGAGgKAAQgJAAgGgGgAgIgLQgEAFAAAGQAAAHAEAEQADAEAFAAQAGAAADgEQAEgEAAgHQAAgGgEgFQgDgEgGABQgFgBgDAEg");
	this.shape_123.setTransform(77.425,584.75);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgEAhIAAgqIAIAAIAAAqgAgEgWQAAAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQABAAAAgBQAAgBAAAAQABAAABgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQABAAAAABQAAABABAAQAAABAAAAQAAABAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAQgBAAAAgBQgBAAgBgBg");
	this.shape_124.setTransform(73.55,583.6);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgLATQgEgEgBgEIAIgDQAAADADACQADACADAAQAEAAACgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgFgGgBIgGgBQgGgBgCgCQgDgEAAgEQAAgGAEgEQAFgEAFAAQAIAAAFAEQADADABAEIgIAEQgBgIgIAAQgCAAgCACQgBAAAAABQgBAAAAABQAAAAAAABQAAAAAAABQAAAEAFABIAGABQAMADAAAKQAAAEgEAFQgEAEgIAAQgHAAgFgEg");
	this.shape_125.setTransform(70.125,584.75);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgLATQgEgEgBgEIAIgDQAAADADACQADACADAAQAEAAACgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgFgGgBIgGgBQgGgBgCgCQgDgEAAgEQAAgGAEgEQAFgEAFAAQAIAAAFAEQADADABAEIgIAEQgBgIgIAAQgCAAgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAEAFABIAGABQAMADAAAKQAAAEgEAFQgEAEgIAAQgHAAgFgEg");
	this.shape_126.setTransform(65.875,584.75);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgNARQgHgHAAgKQAAgJAHgHQAGgGAHAAQAKAAAGAGQAFAGAAAKIAAADIggAAQAAAFAEADQAEAEAEAAQAJAAADgJIAIADQgCAGgFAEQgGAEgHAAQgIAAgGgGgAAMgEQAAgEgDgEQgDgDgGABQgEAAgDADQgDADgBAEIAXAAIAAAAg");
	this.shape_127.setTransform(61.275,584.75);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgLAWIAAgqIAIAAIAAAIQAEgJAJAAIACABIAAAIIgDAAQgLAAgBAMIAAAWg");
	this.shape_128.setTransform(57.25,584.7);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgUAfIAAg8IAIAAIAAAHQAEgIAJAAQAKAAAFAHQAGAGgBAKQABAJgGAGQgGAHgJAAQgJAAgEgHIAAAXgAgJgSQgDAEAAAHQAAAHADADQAEAEAFAAQAFAAAEgEQADgDAAgHQAAgHgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_129.setTransform(52.7,585.525);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AAYAWIAAgaQgBgKgIAAQgFAAgDADQgDADAAAFIAAAZIgHAAIAAgaQAAgKgKAAQgEAAgCADQgEADAAAFIAAAZIgIAAIAAgqIAIAAIAAAGQAFgHAJAAQAJAAACAIQAFgIAKAAQAGAAAEAEQAFAEAAAIIAAAbg");
	this.shape_130.setTransform(45.85,584.675);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgDAhIAAgqIAHAAIAAAqgAgDgWQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQABAAAAgBQAAgBABAAQAAAAABgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQAAAAABABQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAQgBAAAAgBQgBAAAAgBg");
	this.shape_131.setTransform(40.65,583.6);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgBAZQgDgDAAgGIAAgWIgIAAIAAgIIACAAQAHAAAAgHIAAgHIAGAAIAAAOIAKAAIAAAIIgKAAIAAAVQAAAGAHAAIADAAIAAAHIgGABQgGAAgCgEg");
	this.shape_132.setTransform(35.2,584.075);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgLATQgEgEgBgEIAIgDQAAADADACQADACADAAQAEAAACgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgFgGgBIgGgBQgGgBgCgCQgDgEAAgEQAAgGAEgEQAFgEAFAAQAIAAAFAEQADADABAEIgIAEQgBgIgIAAQgCAAgCACQgBAAAAABQgBAAAAABQAAAAAAABQAAAAAAABQAAAEAFABIAGABQAMADAAAKQAAAEgEAFQgEAEgIAAQgHAAgFgEg");
	this.shape_133.setTransform(31.425,584.75);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgDAhIAAgqIAHAAIAAAqgAgDgWQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQABAAAAgBQAAgBABAAQAAAAABgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQAAAAABABQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAQgBAAAAgBQgBAAAAgBg");
	this.shape_134.setTransform(28.15,583.6);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AAAAZQgEgDAAgGIAAgWIgIAAIAAgIIACAAQAHAAAAgHIAAgHIAGAAIAAAOIAKAAIAAAIIgKAAIAAAVQABAGAGAAIADAAIAAAHIgGABQgFAAgCgEg");
	this.shape_135.setTransform(25.15,584.075);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgLAWIAAgqIAIAAIAAAIQADgJAKAAIACABIAAAIIgEAAQgKAAgBAMIAAAWg");
	this.shape_136.setTransform(22.05,584.7);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AAVAgIgHgSIgcAAIgGASIgKAAIAag/IAJAAIAZA/gAALAGIgLgbIgKAbIAVAAg");
	this.shape_137.setTransform(16.85,583.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82}]}).wait(285));

	// Register_btn
	this.instance_11 = new lib.Registerbtn();
	this.instance_11.parent = this;
	this.instance_11.setTransform(150,455,1.2274,1.2274,0,0,0,0,-2.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(285));

	// BKG
	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#F26522").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_138.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_138).wait(285));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(68,276.1,338.6,323.9);
// library properties:
lib.properties = {
	id: '56DC97A13D194E2C906C95BBEC24E126',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Half_page_300x600/gh-pages/images/IMG01jpgcopy.jpg", id:"IMG01jpgcopy"},
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Half_page_300x600/gh-pages/images/IMG02jpgcopy.jpg", id:"IMG02jpgcopy"},
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Half_page_300x600/gh-pages/images/IMG03.jpg", id:"IMG03"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['56DC97A13D194E2C906C95BBEC24E126'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;